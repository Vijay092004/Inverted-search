#include "index.h"

int validate_file(char *filename)// Validates whether the given file exists and is a valid .txt file.
{
    char *ext = strstr(filename, ".txt");

    if (ext == NULL || strcmp(ext, ".txt") != 0)
    {
        printf("%s is not a .txt file\n", filename);
        return -1;
    }

    FILE *fp = fopen(filename, "r");
    if (fp == NULL)
    {
        printf("%s not found\n", filename);
        return -1;
    }

    fclose(fp);
    return 0;
}