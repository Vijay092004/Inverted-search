#include "index.h"

int search_word(char *word)// Searches for a word in the database and displays file occurrence details.
{
    int index = hash_function(word);

    MainNode *m = hash_table[index];

    while (m)
    {
        if (strcmp(m->word, word) == 0)
        {
            printf("\nFound '%s'\n", word);

            SubNode *s = m->sub_link;
            while (s)
            {
                printf("File: %s | Count: %d\n", s->filename, s->word_count);
                s = s->sub_link;
            }
            return 0;
        }
        m = m->main_link;
    }

    printf("Word not found\n");
    return -1;
}