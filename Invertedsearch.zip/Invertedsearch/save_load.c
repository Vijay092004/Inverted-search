#include "index.h"

int save_database(char *filename)// Saves the current database contents into a file.
{
    FILE *fp = fopen(filename, "w");

    if (!fp)
        return -1;

    for (int i = 0; i < HASH_SIZE; i++)
    {
        MainNode *m = hash_table[i];

        while (m)
        {
            fprintf(fp,"%s",m->word);

            SubNode*s = m->sub_link;
            while(s)
            {
                fprintf(fp, ";%s;%d", s->filename, s->word_count);
                s = s->sub_link;
            }

            fprintf(fp, "\n");
            m = m->main_link;
        }
    }

    fclose(fp);
    printf("Database saved\n");
    return 0;
}

int update_database(char *filename)// Loads database contents from a saved file into memory.
{
    FILE *fp = fopen(filename, "r");

    if (!fp)
        return -1;

    char line[200];

    while (fgets(line, sizeof(line), fp))
    {
        char *token = strtok(line, ";\n");

        char word[50];
        strcpy(word, token);
        
        token = strtok(NULL, ";\n");

        while (token)
        {
            char file[50];
            strcpy(file, token);

            token = strtok(NULL, ";\n");
            int count = atoi(token);

            for (int i = 0; i < count; i++)
                insert_word(word, file);

            token = strtok(NULL, ";\n");
        }
    }

    fclose(fp);
    printf("Database loaded\n");
    return 0;
}