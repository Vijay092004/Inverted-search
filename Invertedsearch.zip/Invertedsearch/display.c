#include "index.h"

void display_database()// Displays the complete inverted search database content.
{
    for (int i = 0; i < HASH_SIZE; i++)
    {
        MainNode *m = hash_table[i];

        if (m)
        {
            printf("\nIndex %d:\n", i);
        }

        while (m)
        {
            printf("%s -> ", m->word);

            SubNode *s = m->sub_link;
            while (s)
            {
                printf("%s(%d) ", s->filename, s->word_count);
                s = s->sub_link;
            }

            printf("\n");
            m = m->main_link;
        }
    }
}