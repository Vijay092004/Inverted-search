#ifndef INDEX_H
#define INDEX_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define HASH_SIZE 26

typedef struct sub_node
{
    int word_count;
    char filename[50];
    struct sub_node *sub_link;
} SubNode;

typedef struct main_node
{
    char word[50];
    SubNode *sub_link;
    struct main_node *main_link;
} MainNode;

extern MainNode *hash_table[HASH_SIZE];

// functions
int create_database(char *filename);
int insert_word(char *word, char *filename);
int search_word(char *word);
void display_database();
int save_database(char *filename);
int update_database(char *filename);
int hash_function(char *word);

// validation
int validate_file(char *filename);

#endif