#include "index.h"

int insert_word(char *word, char *filename)// Inserts a word into the hash table and updates file count information.
{
    int index = hash_function(word);

    if (index < 0 || index >= HASH_SIZE)
        return -1;

    MainNode *m = hash_table[index];

    while (m)
    {
        if (strcmp(m->word, word) == 0)
        {
            SubNode *s = m->sub_link;

            while (s)
            {
                if (strcmp(s->filename, filename) == 0)
                {
                    s->word_count++;
                    return 0;
                }
                s = s->sub_link;
            }

            SubNode *new_sub = malloc(sizeof(SubNode));
            strcpy(new_sub->filename, filename);
            new_sub->word_count = 1;
            new_sub->sub_link = m->sub_link;
            m->sub_link = new_sub;

            return 0;
        }
        m = m->main_link;
    }

    MainNode *new_main = malloc(sizeof(MainNode));
    strcpy(new_main->word, word);
    new_main->main_link = hash_table[index];
    hash_table[index] = new_main;

    SubNode *new_sub = malloc(sizeof(SubNode));
    strcpy(new_sub->filename, filename);
    new_sub->word_count = 1;
    new_sub->sub_link = NULL;

    new_main->sub_link = new_sub;

    return 0;
}