#include "index.h"

int create_database(char *filename)// Creates database entries for all words present in a file.
{
    FILE *fp = fopen(filename, "r");

    if (fp == NULL)
    {
        printf("File %s not found\n", filename);
        return -1;
    }

    char word[50];
    while (fscanf(fp, "%s", word) != EOF)
    {
        insert_word(word, filename);
    }

    fclose(fp);
    printf("Database created for %s\n", filename);
    return 0;
}