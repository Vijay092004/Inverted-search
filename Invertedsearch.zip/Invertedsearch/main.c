/*Name:D.vijay rohit
Date:25-01-26
The Inverted Search project is a file indexing system developed using the C programming language.
It reads multiple text files, extracts words, and stores them in a hash table-based database along with the file names and occurrence count. 
The project allows efficient searching of a word to identify in which files it is present and how many times it appears. 
It also supports saving the database into a file and reloading it later.
This project demonstrates concepts like hashing, linked lists, file handling, and data structures.
*/
#include "index.h"
MainNode *hash_table[HASH_SIZE];
int main(int argc, char *argv[])// Initializes hash table, handles menu operations, and controls the inverted search workflow.
{
    int choice;
    char word[50], dbfile[50];

    // initialize
    for (int i = 0; i < HASH_SIZE; i++)
        hash_table[i] = NULL;

    if (argc < 2)
    {
        printf("Usage: ./a.out file1.txt file2.txt ...\n");
        return 0;
    }

    while (1)
    {
        printf("\n1.Create DB\n2.Display\n3.Search\n4.Save\n5.Load\n6.Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            for (int i = 1; i < argc; i++)
            {
                if (validate_file(argv[i]) == 0)
                {
                    printf("Processing %s...\n", argv[i]);
                    create_database(argv[i]);
                }
            }
            break;

        case 2:
            display_database();
            break;

        case 3:
            printf("Enter word: ");
            scanf("%s", word);
            search_word(word);
            break;

        case 4:
            printf("Enter DB file name: ");
            scanf("%s", dbfile);
            save_database(dbfile);
            break;

        case 5:
            printf("Enter DB file name: ");
            scanf("%s", dbfile);
            update_database(dbfile);
            break;

        case 6:
            exit(0);
        }
    }
}