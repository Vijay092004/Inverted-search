#include "index.h"

int hash_function(char *word)// Generates hash index value based on the first character of the word.
{
    return word[0] - 'a';
}